<?php
	get_header();


echo '<div id="news_content">';
echo '<div class="news">';
echo $message;
echo '</div>';
echo '</div>';


	get_footer();
?>